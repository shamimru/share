import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from '../Services/service.service';

@Component({
  selector: 'app-blog-details',
  templateUrl: './blog-details.component.html',
  styleUrls: ['./blog-details.component.css']
})
export class BlogDetailsComponent implements OnInit {


  constructor(
    private route:ActivatedRoute,
    private service:ServiceService
  ) {
  
   }

  blogId:any;
  blogByid:any;

  ngOnInit(): void {
    this.blogId=this.route.snapshot.params["blog_id"];
   



    // getBlogBy Id 

    this.blogByid=this.service.getBlogById(this.blogId).subscribe(
      (data:any)=>{
      
        this.blogByid=data;
      }
    )
  }
  // end of oninit 
  comment:any
  submitComment(){
    this.service.saveComment(this.comment).subscribe(
      (data:any)=>{
        
      }
    );
  }

}
