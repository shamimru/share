package com.example.demo.DAO;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Blog;
import com.example.demo.Entity.Comments;
import com.example.demo.Entity.Reply;

@RestController
@CrossOrigin("*")
public class BlogController {

	public BlogController() {
		// TODO Auto-generated constructor stub
	}

	@GetMapping("/getAllBlog")
	public List<Blog> getAllBlog() {

		BlogDAO dao = new BlogDAO();
		List<Blog> blog = dao.getBlog();

		return blog;

	}

//	getBlog by id 
	@GetMapping("/getBlogById/{blog_id}")
	public Blog getBlogById(@PathVariable int blog_id) {
		BlogDAO dao = new BlogDAO();
		Blog blogById = dao.getBlogById(blog_id);

		return blogById;
	}

	
	@GetMapping("/getAllReply")
	public List<Reply>getAllReply() {
		BlogDAO dao = new BlogDAO();
		List<Reply> replyData = dao.getReplyData();
		return replyData;
	}
	
//	saveComment
	
	public void saveComment (Comments c) {
		BlogDAO dao = new BlogDAO();
		dao.saveComments(c);		
	}
}
