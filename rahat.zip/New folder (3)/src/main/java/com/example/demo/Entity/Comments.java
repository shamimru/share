package com.example.demo.Entity;

public class Comments {
	
	
	int comment_id;
	int blog_id;
	String comments;
	String comm_date;
	public Comments() {
		// TODO Auto-generated constructor stub
	}
	public Comments(int comment_id, int blog_id, String comments, String comm_date) {
		super();
		this.comment_id = comment_id;
		this.blog_id = blog_id;
		this.comments = comments;
		this.comm_date = comm_date;
	}
	public int getComment_id() {
		return comment_id;
	}
	public void setComment_id(int comment_id) {
		this.comment_id = comment_id;
	}
	public int getBlog_id() {
		return blog_id;
	}
	public void setBlog_id(int blog_id) {
		this.blog_id = blog_id;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getComm_date() {
		return comm_date;
	}
	public void setComm_date(String comm_date) {
		this.comm_date = comm_date;
	}
	@Override
	public String toString() {
		return "Comments [comment_id=" + comment_id + ", blog_id=" + blog_id + ", comments=" + comments + ", comm_date="
				+ comm_date + "]";
	}
	
	

}
