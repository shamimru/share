
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author IDB-CF
 */
@ManagedBean
@SessionScoped
public class Signup {
    
  private int id;
  private String name;
  private String email;
  private int pass;

    public Signup() {
    }

    public Signup(int id, String name, String email, int pass) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.pass = pass;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getPass() {
        return pass;
    }

    public void setPass(int pass) {
        this.pass = pass;
    }

  
    
    public  String register(){
        String ret= "success.xhtml";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/shamim","root","root");
            PreparedStatement stm=con.prepareStatement("insert into student_2 (id, name,email,pass) values(?,?,?,?)");
            stm.setInt(1,id);
            stm.setString(2, name);
            stm.setString(3,email);
            stm.setInt(4,pass);
            stm.execute();
            System.out.println("success");
            stm.close();
            con.close();
            ret="success.xhtml";
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
        return ret;
    }
  
    
    
    
}
