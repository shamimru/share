import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumlistService {

  // list: number[] = [100];


  list1:number[]=[20];
  constructor() { }
 

  addnumber(val:number){
    this.list1.push(val);
    // alert(val+" is addedd to the array");
  }

  getnumber(){
    return this.list1;
  }


}
