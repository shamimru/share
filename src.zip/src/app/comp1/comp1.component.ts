import { Component, OnInit } from '@angular/core';
import { NumlistService } from '../services/numlist.service';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component implements OnInit {

  // list:number[]=[];
  // constructor(private _numlistService: NumlistService) { }
  
  constructor(private _numListService:NumlistService){

  }

  ngOnInit(): void {
    // this.list=this._numlistService.getnumber();
  }

  list1:number[]=[];
  addnumber(val:any){
    this._numListService.addnumber(val);
    this.list1=this._numListService.getnumber();
    // this.list1.push(val);
  }

  // addnumber(num: any) {

  //   this._numlistService.addnumber(num);
  // }
}
