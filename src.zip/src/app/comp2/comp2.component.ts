import { Component, OnInit } from '@angular/core';
import { NumlistService } from '../services/numlist.service';

@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css']
})
export class Comp2Component implements OnInit {

  list1:number[]=[];
  constructor(private _numListService:NumlistService) { }

  ngOnInit(): void {
  }

  addnumber(val:any){

    this._numListService.addnumber(val);
    // alert(val+" is addedd to the services")
  }
  getnumber(){
    this.list1=this._numListService.getnumber()
  }

}
