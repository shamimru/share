
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author My Pc
 */
@ManagedBean
@SessionScoped
public class Test {

    int id;
    String name;
    String email;
    int password;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public String signup() {
        String ret = "failSignUp";

        try {
//            this.id=0;
//            this.name="";
//            this.email="";
//            this.password=0;
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/college", "root", "root");
            PreparedStatement ps = con.prepareStatement("insert into student(id,name,email,password) values(?,?,?,?)");
            ps.setInt(1, this.id);
            ps.setString(2, this.name);
            ps.setString(3, this.email);
            ps.setInt(4, this.password);
            ps.executeUpdate();

            con.close();
            ret = "successSignUp";
        } catch (Exception e) {
            System.out.println(e);
        }
        return ret;
    }

    public String signin() {

        String ret = "signInFail";

        try {
          
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/college", "root", "root");
            PreparedStatement stm = con.prepareStatement("select * from student where id=? and password=?");

            stm.setInt(1, this.id);
            stm.setInt(2, this.password);

            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                ret = "signInSuccess";
                this.id = rs.getInt(1);
                this.name = rs.getString(2);
                this.name = rs.getString(3);
                this.id = rs.getInt(4);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return ret;
    }
}
